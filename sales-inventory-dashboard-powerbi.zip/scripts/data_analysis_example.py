import pandas as pd

# Carregar dados
df = pd.read_csv('../data/sales_inventory_sample.csv')

# Exibir primeiras linhas
print(df.head())

# Exemplo de cálculo: total de vendas por produto
sales_by_product = df.groupby('Product')['Sales'].sum().reset_index()
print(sales_by_product)
